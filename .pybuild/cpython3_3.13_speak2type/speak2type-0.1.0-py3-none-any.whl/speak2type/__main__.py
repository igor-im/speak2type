"""Entry point for running speak2type as a module."""

from speak2type.engine import main

if __name__ == "__main__":
    main()
