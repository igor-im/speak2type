"""speak2type - Speech-to-text IBus engine for Linux desktops."""

__version__ = "0.1.0"
